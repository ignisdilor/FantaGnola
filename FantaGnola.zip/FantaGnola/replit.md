# FantaGnola - Online Voting System

## Overview

FantaGnola is a modern full-stack web application for creating and managing online polls and voting campaigns. The application provides a comprehensive voting platform with real-time results, user authentication, and administrative controls. Built with a React frontend and Express.js backend, it uses PostgreSQL for data persistence and features a responsive, mobile-friendly design.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client and server code:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js with TypeScript for API endpoints
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Authentication**: Session-based authentication with express-session

## Key Components

### Frontend Architecture
- **Component Structure**: Uses shadcn/ui components for consistent design system
- **Routing**: wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **State Management**: TanStack Query for API state with optimistic updates

### Backend Architecture
- **API Structure**: RESTful API with Express.js middleware
- **Database Layer**: Drizzle ORM with connection pooling via Neon serverless
- **Session Management**: In-memory session store with express-session
- **Request Logging**: Custom middleware for API request/response logging
- **Error Handling**: Centralized error handling middleware

### Database Schema
- **Users Table**: User authentication and profile information
- **Polls Table**: Poll metadata, options stored as JSONB, status tracking
- **Votes Table**: Individual vote records with foreign key relationships
- **Sessions Table**: Session storage for authentication persistence

### Authentication System
- **Registration/Login**: Username/password authentication
- **Session Persistence**: Server-side session management
- **Route Protection**: Authentication middleware for protected endpoints
- **User Context**: React Query for user state management

## Data Flow

1. **Authentication Flow**: Users register/login → session created → user context established
2. **Poll Creation**: Authenticated users create polls → stored in database → real-time updates
3. **Voting Process**: Users select options → votes recorded → immediate UI feedback → statistics updated
4. **Real-time Updates**: TanStack Query automatic refetching for live poll results
5. **Session Management**: Express-session handles authentication state persistence

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: PostgreSQL connection via Neon's serverless driver
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management and caching
- **express-session**: Session-based authentication middleware

### UI/UX Dependencies
- **@radix-ui**: Unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **react-hook-form**: Form state management and validation
- **@hookform/resolvers**: Zod integration for form validation

### Development Dependencies
- **vite**: Fast development server and build tool
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Development Environment
- **Development Server**: Vite dev server with HMR for frontend
- **Backend Server**: tsx with nodemon-like functionality for auto-restart
- **Database**: Neon serverless PostgreSQL with connection pooling
- **Environment Variables**: DATABASE_URL required for database connection

### Production Build Process
1. **Frontend Build**: Vite builds React app to `dist/public`
2. **Backend Build**: esbuild bundles server code to `dist/index.js`
3. **Database Migrations**: Drizzle Kit handles schema migrations
4. **Static Serving**: Express serves built frontend assets

### Key Configuration Files
- **vite.config.ts**: Frontend build configuration with path aliases
- **drizzle.config.ts**: Database migration and schema configuration
- **tsconfig.json**: TypeScript configuration for monorepo structure
- **tailwind.config.ts**: Design system and component styling configuration

### Session Storage
- **Development**: In-memory session store (MemoryStore)
- **Production**: Configurable session store (can be upgraded to Redis/PostgreSQL)
- **Security**: HTTP-only cookies with configurable secure flag

The application is designed for easy deployment on platforms that support Node.js with PostgreSQL, with particular optimization for Replit's environment through custom Vite plugins and development tooling.