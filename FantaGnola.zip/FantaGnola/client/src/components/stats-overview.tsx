import { TrendingUp, CheckCircle, Users, Trophy } from "lucide-react";

interface StatsOverviewProps {
  stats?: {
    totalVotes: number;
    activePolls: number;
    completedPolls: number;
    participants: number;
  };
}

export default function StatsOverview({ stats }: StatsOverviewProps) {
  const defaultStats = {
    totalVotes: 0,
    activePolls: 0,
    completedPolls: 0,
    participants: 0,
  };

  const currentStats = stats || defaultStats;

  const statCards = [
    {
      title: "Votazioni Attive",
      value: currentStats.activePolls,
      icon: TrendingUp,
      bgColor: "bg-primary-100",
      iconColor: "text-primary-700",
    },
    {
      title: "Voti Totali",
      value: currentStats.totalVotes.toLocaleString('it-IT'),
      icon: CheckCircle,
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
    },
    {
      title: "Partecipanti",
      value: currentStats.participants.toLocaleString('it-IT'),
      icon: Users,
      bgColor: "bg-blue-100",
      iconColor: "text-blue-600",
    },
    {
      title: "Completate",
      value: currentStats.completedPolls,
      icon: Trophy,
      bgColor: "bg-purple-100",
      iconColor: "text-purple-600",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      {statCards.map((stat, index) => (
        <div key={index} className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">{stat.title}</p>
              <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
            </div>
            <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
              <stat.icon className={`${stat.iconColor} w-6 h-6`} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
