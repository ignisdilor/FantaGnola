import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Play, Pause, CheckCircle, UserPlus, BarChart3 } from "lucide-react";
import type { PollWithVotes } from "@shared/schema";

interface AdminControlsProps {
  polls: PollWithVotes[];
}

export default function AdminControls({ polls }: AdminControlsProps) {
  const [promoteUserId, setPromoteUserId] = useState("");
  const [showResults, setShowResults] = useState<number | null>(null);
  const [pollResults, setPollResults] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updatePollStatusMutation = useMutation({
    mutationFn: async ({ pollId, status }: { pollId: number; status: string }) => {
      return apiRequest(`/api/polls/${pollId}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/polls"] });
      toast({ title: "Stato votazione aggiornato" });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const promoteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return apiRequest(`/api/admin/promote/${userId}`, {
        method: "POST",
      });
    },
    onSuccess: () => {
      setPromoteUserId("");
      toast({ title: "Utente promosso ad admin" });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getPollResultsMutation = useMutation({
    mutationFn: async (pollId: number) => {
      return apiRequest(`/api/polls/${pollId}/results`);
    },
    onSuccess: (data) => {
      setPollResults(data);
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (pollId: number, newStatus: string) => {
    updatePollStatusMutation.mutate({ pollId, status: newStatus });
  };

  const handlePromoteUser = () => {
    if (promoteUserId) {
      promoteUserMutation.mutate(promoteUserId);
    }
  };

  const handleViewResults = (pollId: number) => {
    setShowResults(pollId);
    getPollResultsMutation.mutate(pollId);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500";
      case "completed":
        return "bg-blue-500";
      case "draft":
        return "bg-gray-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "Attiva";
      case "completed":
        return "Completata";
      case "draft":
        return "Bozza";
      default:
        return status;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5" />
            Gestione Admin
          </CardTitle>
          <CardDescription>
            Promuovi utenti ad admin per gestire le votazioni
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="ID utente da promuovere"
              value={promoteUserId}
              onChange={(e) => setPromoteUserId(e.target.value)}
              type="number"
            />
            <Button
              onClick={handlePromoteUser}
              disabled={!promoteUserId || promoteUserMutation.isPending}
            >
              Promuovi
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Gestione Votazioni</CardTitle>
          <CardDescription>
            Controlla lo stato delle votazioni e visualizza i risultati
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {polls.map((poll) => (
              <div
                key={poll.id}
                className="flex items-center justify-between p-4 border rounded-lg"
              >
                <div className="flex-1">
                  <h3 className="font-semibold">{poll.title}</h3>
                  <p className="text-sm text-gray-600 mb-2">{poll.description}</p>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(poll.status)}>
                      {getStatusLabel(poll.status)}
                    </Badge>
                    <span className="text-sm text-gray-500">
                      {poll.voteCount} voti
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {poll.status === "draft" && (
                    <Button
                      size="sm"
                      onClick={() => handleStatusChange(poll.id, "active")}
                      disabled={updatePollStatusMutation.isPending}
                    >
                      <Play className="h-4 w-4" />
                      Avvia
                    </Button>
                  )}
                  {poll.status === "active" && (
                    <Button
                      size="sm"
                      onClick={() => handleStatusChange(poll.id, "completed")}
                      disabled={updatePollStatusMutation.isPending}
                    >
                      <CheckCircle className="h-4 w-4" />
                      Completa
                    </Button>
                  )}
                  {poll.status === "completed" && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleViewResults(poll.id)}
                    >
                      <BarChart3 className="h-4 w-4" />
                      Risultati
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Dialog per i risultati */}
      <Dialog open={showResults !== null} onOpenChange={() => setShowResults(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Risultati Votazione</DialogTitle>
          </DialogHeader>
          {pollResults && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-lg">{pollResults.poll.title}</h3>
                <p className="text-gray-600">{pollResults.poll.description}</p>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800">Vincitore</h4>
                <p className="text-green-700">{pollResults.winner}</p>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Distribuzione Voti</h4>
                <div className="space-y-2">
                  {pollResults.poll.options.map((option: string, index: number) => (
                    <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                      <span>{option}</span>
                      <Badge variant="outline">
                        {pollResults.voteCounts[index] || 0} voti
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Partecipanti ({pollResults.participants.length})</h4>
                <div className="max-h-40 overflow-y-auto space-y-1">
                  {pollResults.participants.map((participant: any, index: number) => (
                    <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded text-sm">
                      <span>{participant.name}</span>
                      <span className="text-gray-600">{participant.vote}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}