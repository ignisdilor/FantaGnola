import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Clock, Users, MoreVertical, Crown, ArrowRight, Download, Edit, Eye } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import type { PollWithVotes } from "@shared/schema";

interface PollCardProps {
  poll: PollWithVotes;
  onUpdate: () => void;
}

export default function PollCard({ poll, onUpdate }: PollCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  const voteMutation = useMutation({
    mutationFn: async (optionIndex: number) => {
      return await apiRequest("POST", `/api/polls/${poll.id}/vote`, {
        optionIndex,
      });
    },
    onSuccess: () => {
      toast({
        title: "Voto registrato!",
        description: "Il tuo voto è stato registrato con successo.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/polls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      onUpdate();
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore durante la votazione",
        variant: "destructive",
      });
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      return await apiRequest("PATCH", `/api/polls/${poll.id}`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Stato aggiornato!",
        description: "Lo stato della votazione è stato aggiornato.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/polls"] });
      onUpdate();
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore durante l'aggiornamento",
        variant: "destructive",
      });
    },
  });

  const handleVote = (optionIndex: number) => {
    setSelectedOption(optionIndex);
    voteMutation.mutate(optionIndex);
  };

  const handlePublish = () => {
    updateStatusMutation.mutate("active");
  };

  const handleComplete = () => {
    updateStatusMutation.mutate("completed");
  };

  const getStatusBadge = () => {
    switch (poll.status) {
      case "active":
        return <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">Attiva</Badge>;
      case "completed":
        return <Badge variant="secondary" className="bg-gray-100 text-gray-800">Completata</Badge>;
      case "draft":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Bozza</Badge>;
      default:
        return <Badge variant="secondary">Sconosciuto</Badge>;
    }
  };

  const getTimeRemaining = () => {
    if (!poll.expiresAt) return null;
    
    const now = new Date();
    const expires = new Date(poll.expiresAt);
    const diff = expires.getTime() - now.getTime();
    
    if (diff <= 0) return "Scaduta";
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) return `Scade in ${days} giorni`;
    if (hours > 0) return `Scade in ${hours} ore`;
    return "Scade presto";
  };

  const getWinningOption = () => {
    if (poll.status !== 'completed' || poll.voteCount === 0) return null;
    
    let maxVotes = 0;
    let winningIndex = 0;
    
    Object.entries(poll.voteCounts).forEach(([index, count]) => {
      if (count > maxVotes) {
        maxVotes = count;
        winningIndex = parseInt(index);
      }
    });
    
    return winningIndex;
  };

  const winningOption = getWinningOption();

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900">{poll.title}</h3>
            {poll.description && (
              <p className="text-sm text-gray-600 mt-1">{poll.description}</p>
            )}
          </div>
          <div className="flex items-center space-x-2">
            {poll.status === 'active' && poll.showRealTimeResults && (
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-xs text-green-600 font-medium">Live</span>
              </div>
            )}
            {getStatusBadge()}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {poll.status === 'draft' && (
                  <DropdownMenuItem onClick={handlePublish}>
                    <Eye className="w-4 h-4 mr-2" />
                    Pubblica
                  </DropdownMenuItem>
                )}
                {poll.status === 'active' && (
                  <DropdownMenuItem onClick={handleComplete}>
                    <Crown className="w-4 h-4 mr-2" />
                    Completa
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem>
                  <Edit className="w-4 h-4 mr-2" />
                  Modifica
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div className="space-y-3 mb-6">
          {poll.options.map((option, index) => {
            const voteCount = poll.voteCounts[index] || 0;
            const percentage = poll.voteCount > 0 ? (voteCount / poll.voteCount) * 100 : 0;
            const isWinner = poll.status === 'completed' && winningOption === index;
            const canVote = poll.status === 'active';

            return (
              <div
                key={index}
                className={`flex items-center justify-between p-3 border rounded-lg transition-colors ${
                  isWinner
                    ? 'bg-green-50 border-green-200'
                    : canVote
                    ? 'border-gray-200 hover:bg-gray-50 cursor-pointer'
                    : 'border-gray-200 opacity-60'
                }`}
                onClick={canVote ? () => handleVote(index) : undefined}
              >
                <div className="flex items-center space-x-3">
                  {isWinner && <Crown className="w-4 h-4 text-green-600" />}
                  {canVote && !isWinner && (
                    <div className={`w-4 h-4 border-2 rounded-full flex items-center justify-center ${
                      selectedOption === index ? 'border-primary-700' : 'border-gray-300'
                    }`}>
                      {selectedOption === index && (
                        <div className="w-2 h-2 bg-primary-700 rounded-full"></div>
                      )}
                    </div>
                  )}
                  {poll.status === 'draft' && (
                    <div className="w-4 h-4 bg-gray-300 rounded-full"></div>
                  )}
                  <span className="font-medium text-gray-900">{option}</span>
                </div>
                {poll.status !== 'draft' && (
                  <div className="flex items-center space-x-2">
                    <Progress
                      value={percentage}
                      className={`w-24 h-2 ${
                        isWinner ? 'bg-green-200' : 'bg-gray-200'
                      }`}
                    />
                    <span className={`text-sm font-medium ${
                      isWinner ? 'text-green-700' : 'text-gray-600'
                    }`}>
                      {Math.round(percentage)}%
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between text-sm text-gray-600">
          <div className="flex items-center space-x-4">
            <span className="flex items-center">
              <Users className="w-4 h-4 mr-1" />
              {poll.voteCount} voti
            </span>
            {poll.status === 'active' && getTimeRemaining() && (
              <span className="flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                {getTimeRemaining()}
              </span>
            )}
            {poll.status === 'completed' && (
              <span className="flex items-center text-green-600">
                <Crown className="w-4 h-4 mr-1" />
                Completata
              </span>
            )}
            {poll.status === 'draft' && (
              <span className="flex items-center">
                <Edit className="w-4 h-4 mr-1" />
                Modifica per pubblicare
              </span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            {poll.status === 'active' && (
              <Button
                variant="ghost"
                size="sm"
                className="text-primary-700 hover:text-primary-800 font-medium"
              >
                Vedi Risultati
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            )}
            {poll.status === 'completed' && (
              <Button
                variant="ghost"
                size="sm"
                className="text-primary-700 hover:text-primary-800 font-medium"
              >
                <Download className="w-4 h-4 mr-1" />
                Esporta
              </Button>
            )}
            {poll.status === 'draft' && (
              <Button
                onClick={handlePublish}
                disabled={updateStatusMutation.isPending}
                className="bg-primary-700 hover:bg-primary-800 text-white px-4 py-2 rounded-lg text-sm font-medium"
              >
                Pubblica
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
