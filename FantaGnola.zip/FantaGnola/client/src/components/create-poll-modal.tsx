import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPollSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, X } from "lucide-react";
import { z } from "zod";

const formSchema = insertPollSchema.extend({
  expiresAt: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

interface CreatePollModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export default function CreatePollModal({ open, onOpenChange, onSuccess }: CreatePollModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [options, setOptions] = useState<string[]>(["", ""]);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      options: ["", ""],
      status: "draft",
      allowMultipleVotes: false,
      showRealTimeResults: true,
      createdBy: 1,
    },
  });

  const createPollMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const pollData = {
        ...data,
        options: options.filter(option => option.trim() !== ""),
        expiresAt: data.expiresAt ? new Date(data.expiresAt) : undefined,
      };
      return await apiRequest("POST", "/api/polls", pollData);
    },
    onSuccess: () => {
      toast({
        title: "Votazione creata!",
        description: "La tua votazione è stata creata con successo.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/polls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      onSuccess();
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: error.message || "Errore durante la creazione della votazione",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    form.reset();
    setOptions(["", ""]);
    onOpenChange(false);
  };

  const addOption = () => {
    setOptions([...options, ""]);
  };

  const removeOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index));
    }
  };

  const updateOption = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  const onSubmit = (data: FormData) => {
    if (options.filter(option => option.trim() !== "").length < 2) {
      toast({
        title: "Errore",
        description: "Devi inserire almeno 2 opzioni",
        variant: "destructive",
      });
      return;
    }

    createPollMutation.mutate(data);
  };

  const handleSaveDraft = () => {
    form.setValue("status", "draft");
    form.handleSubmit(onSubmit)();
  };

  const handlePublish = () => {
    form.setValue("status", "active");
    form.handleSubmit(onSubmit)();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-bold text-gray-900">
              Crea Nuova Votazione
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">
                    Titolo Votazione
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Inserisci il titolo della votazione..."
                      {...field}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">
                    Descrizione
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Descrivi la votazione..."
                      rows={3}
                      {...field}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Opzioni di Voto
              </label>
              <div className="space-y-3">
                {options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Input
                      placeholder={`Opzione ${index + 1}`}
                      value={option}
                      onChange={(e) => updateOption(index, e.target.value)}
                      className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    />
                    {options.length > 2 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeOption(index)}
                        className="p-3 text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={addOption}
                  className="w-full p-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-primary-500 hover:text-primary-700 transition-colors"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Aggiungi Opzione
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="expiresAt"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-gray-700">
                      Data Scadenza
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="date"
                        {...field}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormItem>
                <FormLabel className="text-sm font-medium text-gray-700">
                  Tipo Votazione
                </FormLabel>
                <Select defaultValue="public">
                  <SelectTrigger className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">Pubblica</SelectItem>
                    <SelectItem value="private">Privata</SelectItem>
                    <SelectItem value="invited">Solo Invitati</SelectItem>
                  </SelectContent>
                </Select>
              </FormItem>
            </div>

            <div className="flex items-center space-x-4">
              <FormField
                control={form.control}
                name="allowMultipleVotes"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="w-4 h-4"
                      />
                    </FormControl>
                    <FormLabel className="text-sm text-gray-700">
                      Consenti voti multipli
                    </FormLabel>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="showRealTimeResults"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="w-4 h-4"
                      />
                    </FormControl>
                    <FormLabel className="text-sm text-gray-700">
                      Mostra risultati in tempo reale
                    </FormLabel>
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium"
              >
                Annulla
              </Button>
              <Button
                type="button"
                onClick={handleSaveDraft}
                disabled={createPollMutation.isPending}
                className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium"
              >
                Salva Bozza
              </Button>
              <Button
                type="button"
                onClick={handlePublish}
                disabled={createPollMutation.isPending}
                className="px-6 py-3 bg-primary-700 hover:bg-primary-800 text-white rounded-lg font-medium"
              >
                Pubblica Votazione
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
