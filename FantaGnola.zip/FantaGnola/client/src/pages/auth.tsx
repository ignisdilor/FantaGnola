import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { UserPlus, LogIn } from "lucide-react";
import { z } from "zod";
import logoPath from "@assets/WhatsApp Image 2025-05-26 at 15.24.53_1749647807725.jpeg";

const loginSchema = z.object({
  username: z.string().min(1, "Username richiesto"),
  password: z.string().min(1, "Password richiesta"),
});

type LoginData = z.infer<typeof loginSchema>;
type RegisterData = z.infer<typeof insertUserSchema>;

export default function Auth() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isLogin, setIsLogin] = useState(true);
  const [showWelcome, setShowWelcome] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowWelcome(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  const loginForm = useForm<LoginData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: "", password: "" },
  });

  const registerForm = useForm<RegisterData>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: { username: "", password: "" },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginData) => {
      return await apiRequest("POST", "/api/auth/login", data);
    },
    onSuccess: (data: any) => {
      localStorage.setItem("user", JSON.stringify(data.user));
      toast({ title: "Accesso effettuato!", description: "Benvenuto in FantaGnola" });
      queryClient.invalidateQueries({ queryKey: ["/api/polls"] });
      window.location.href = "/";
    },
    onError: (error: any) => {
      toast({
        title: "Errore di accesso",
        description: error.message || "Username o password non corretti",
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegisterData) => {
      return await apiRequest("POST", "/api/auth/register", data);
    },
    onSuccess: () => {
      toast({ title: "Registrazione completata!", description: "Ora puoi effettuare l'accesso" });
      setIsLogin(true);
      registerForm.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Errore di registrazione",
        description: error.message || "Errore durante la registrazione",
        variant: "destructive",
      });
    },
  });

  // Schermata di benvenuto semplice
  if (showWelcome) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <img 
            src={logoPath} 
            alt="FantaGnola Logo" 
            className="w-24 h-24 mx-auto mb-6 rounded-2xl shadow-lg object-cover"
          />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">FantaGnola</h1>
          <p className="text-lg text-gray-600 mb-8">
            Benvenuto nell'app ufficiale della lega FANTAGNOLA
          </p>
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
        </div>
      </div>
    );
  }

  // Schermata di login/registrazione semplice
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white rounded-lg shadow-xl p-6">
        
        {/* Logo e titolo */}
        <div className="text-center mb-6">
          <img 
            src={logoPath} 
            alt="FantaGnola Logo" 
            className="w-16 h-16 mx-auto mb-3 rounded-xl shadow-md object-cover"
          />
          <h1 className="text-2xl font-bold text-gray-900">FantaGnola</h1>
          <p className="text-sm text-gray-600">Lega FANTAGNOLA</p>
        </div>

        {/* Switch Login/Registrazione */}
        <div className="flex bg-gray-100 rounded-lg p-1 mb-6">
          <button
            onClick={() => setIsLogin(true)}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md text-sm font-medium transition ${
              isLogin 
                ? "bg-white shadow-sm text-gray-900" 
                : "text-gray-600"
            }`}
          >
            <LogIn className="w-4 h-4" />
            Accedi
          </button>
          <button
            onClick={() => setIsLogin(false)}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md text-sm font-medium transition ${
              !isLogin 
                ? "bg-white shadow-sm text-gray-900" 
                : "text-gray-600"
            }`}
          >
            <UserPlus className="w-4 h-4" />
            Registrati
          </button>
        </div>

        {/* Form Login */}
        {isLogin && (
          <form onSubmit={loginForm.handleSubmit((data) => loginMutation.mutate(data))} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <Input
                {...loginForm.register("username")}
                placeholder="Il tuo username"
                className="w-full"
              />
              {loginForm.formState.errors.username && (
                <p className="text-sm text-red-600 mt-1">{loginForm.formState.errors.username.message}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <Input
                {...loginForm.register("password")}
                type="password"
                placeholder="La tua password"
                className="w-full"
              />
              {loginForm.formState.errors.password && (
                <p className="text-sm text-red-600 mt-1">{loginForm.formState.errors.password.message}</p>
              )}
            </div>
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? "Accesso..." : "Accedi"}
            </Button>
          </form>
        )}

        {/* Form Registrazione */}
        {!isLogin && (
          <form onSubmit={registerForm.handleSubmit((data) => registerMutation.mutate(data))} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <Input
                {...registerForm.register("username")}
                placeholder="Scegli un username"
                className="w-full"
              />
              {registerForm.formState.errors.username && (
                <p className="text-sm text-red-600 mt-1">{registerForm.formState.errors.username.message}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <Input
                {...registerForm.register("password")}
                type="password"
                placeholder="Scegli una password"
                className="w-full"
              />
              {registerForm.formState.errors.password && (
                <p className="text-sm text-red-600 mt-1">{registerForm.formState.errors.password.message}</p>
              )}
            </div>
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={registerMutation.isPending}
            >
              {registerMutation.isPending ? "Registrazione..." : "Registrati"}
            </Button>
          </form>
        )}

      </div>
    </div>
  );
}