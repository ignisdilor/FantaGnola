import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import StatsOverview from "@/components/stats-overview";
import PollCard from "@/components/poll-card";
import CreatePollModal from "@/components/create-poll-modal";
import AdminControls from "@/components/admin-controls";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Plus, RefreshCw } from "lucide-react";
import type { PollWithVotes } from "@shared/schema";

export default function Home() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const { isAdmin } = useAuth();

  const { data: polls = [], isLoading, refetch } = useQuery<PollWithVotes[]>({
    queryKey: ["/api/polls"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm p-6">
                  <div className="h-16 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm p-6">
                  <div className="h-64 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gray-50 overflow-hidden flex flex-col">
      <Header />
      
      <main className="flex-1 overflow-y-auto max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <StatsOverview stats={stats} />
        
        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 space-y-4 sm:space-y-0">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Le Tue Votazioni</h2>
            <p className="text-gray-600 mt-1">Gestisci e monitora le votazioni attive</p>
          </div>
          <div className="flex space-x-3">
            {isAdmin && (
              <Button
                onClick={() => setShowCreateModal(true)}
                className="bg-primary-700 hover:bg-primary-800 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>Nuova Votazione</span>
              </Button>
            )}
            <Button
              onClick={() => refetch()}
              variant="outline"
              className="bg-white hover:bg-gray-50 text-gray-700 px-6 py-3 rounded-lg font-medium border border-gray-300 transition-colors flex items-center space-x-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Aggiorna</span>
            </Button>
          </div>
        </div>

        {/* Admin Controls */}
        {isAdmin && (
          <div className="mb-8">
            <AdminControls polls={polls} />
          </div>
        )}

        {/* Voting List */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {polls.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <div className="text-gray-500">
                <p className="text-lg font-medium">Nessuna votazione trovata</p>
                <p className="mt-2">
                  {isAdmin ? 
                    "Crea la tua prima votazione per iniziare" :
                    "Nessuna votazione è attualmente disponibile."
                  }
                </p>
              </div>
            </div>
          ) : (
            polls.map((poll) => (
              <PollCard key={poll.id} poll={poll} onUpdate={() => refetch()} />
            ))
          )}
        </div>
      </main>

      <CreatePollModal
        open={showCreateModal}
        onOpenChange={setShowCreateModal}
        onSuccess={() => refetch()}
      />
    </div>
  );
}
