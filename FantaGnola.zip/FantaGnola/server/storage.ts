import {
  type User,
  type InsertUser,
  type Poll,
  type InsertPoll,
  type Vote,
  type InsertVote,
  type PollWithVotes,
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  promoteToAdmin(userId: number): Promise<User | undefined>;

  // Poll methods
  getPoll(id: number): Promise<Poll | undefined>;
  getPollWithVotes(id: number): Promise<PollWithVotes | undefined>;
  getAllPolls(): Promise<PollWithVotes[]>;
  createPoll(poll: InsertPoll): Promise<Poll>;
  updatePoll(id: number, updates: Partial<Poll>): Promise<Poll | undefined>;
  deletePoll(id: number): Promise<boolean>;

  // Vote methods
  getVotesForPoll(pollId: number): Promise<Vote[]>;
  createVote(vote: InsertVote): Promise<Vote>;
  getUserVoteForPoll(pollId: number, userId?: number, voterInfo?: string): Promise<Vote | undefined>;
  getVoteStats(): Promise<{ totalVotes: number; activePolls: number; completedPolls: number; participants: number }>;
}

export class MemStorage implements IStorage {
  private users: User[] = [];
  private polls: Poll[] = [];
  private votes: Vote[] = [];
  private nextUserId = 1;
  private nextPollId = 1;
  private nextVoteId = 1;

  async getUser(id: number): Promise<User | undefined> {
    return this.users.find(user => user.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return this.users.find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: this.nextUserId++,
      username: insertUser.username,
      password: insertUser.password,
      email: null,
      role: this.users.length === 0 ? "admin" : "user", // Il primo utente è admin
      createdAt: new Date(),
    };
    this.users.push(user);
    return user;
  }

  async promoteToAdmin(userId: number): Promise<User | undefined> {
    const userIndex = this.users.findIndex(user => user.id === userId);
    if (userIndex === -1) return undefined;

    this.users[userIndex] = { ...this.users[userIndex], role: "admin" };
    return this.users[userIndex];
  }

  async getPoll(id: number): Promise<Poll | undefined> {
    return this.polls.find(poll => poll.id === id);
  }

  async getPollWithVotes(id: number): Promise<PollWithVotes | undefined> {
    const poll = await this.getPoll(id);
    if (!poll) return undefined;

    const pollVotes = this.votes.filter(vote => vote.pollId === id);
    const voteCount = pollVotes.length;
    
    const voteCounts: Record<number, number> = {};
    for (let i = 0; i < poll.options.length; i++) {
      voteCounts[i] = pollVotes.filter(vote => vote.optionIndex === i).length;
    }

    return {
      ...poll,
      votes: pollVotes,
      voteCount,
      voteCounts
    };
  }

  async getAllPolls(): Promise<PollWithVotes[]> {
    const pollsWithVotes: PollWithVotes[] = [];

    for (const poll of this.polls) {
      const pollWithVotes = await this.getPollWithVotes(poll.id);
      if (pollWithVotes) {
        pollsWithVotes.push(pollWithVotes);
      }
    }

    return pollsWithVotes.reverse();
  }

  async createPoll(insertPoll: InsertPoll): Promise<Poll> {
    const poll: Poll = {
      id: this.nextPollId++,
      title: insertPoll.title,
      description: insertPoll.description,
      options: insertPoll.options,
      status: insertPoll.status || 'active',
      userId: insertPoll.userId,
      expiresAt: insertPoll.expiresAt,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.polls.push(poll);
    return poll;
  }

  async updatePoll(id: number, updates: Partial<Poll>): Promise<Poll | undefined> {
    const index = this.polls.findIndex(poll => poll.id === id);
    if (index === -1) return undefined;

    this.polls[index] = { ...this.polls[index], ...updates, updatedAt: new Date() };
    return this.polls[index];
  }

  async deletePoll(id: number): Promise<boolean> {
    const index = this.polls.findIndex(poll => poll.id === id);
    if (index === -1) return false;

    this.polls.splice(index, 1);
    this.votes = this.votes.filter(vote => vote.pollId !== id);
    return true;
  }

  async getVotesForPoll(pollId: number): Promise<Vote[]> {
    return this.votes.filter(vote => vote.pollId === pollId);
  }

  async createVote(insertVote: InsertVote): Promise<Vote> {
    const vote: Vote = {
      id: this.nextVoteId++,
      pollId: insertVote.pollId,
      userId: insertVote.userId,
      optionIndex: insertVote.optionIndex,
      voterInfo: insertVote.voterInfo,
      createdAt: new Date(),
    };
    this.votes.push(vote);
    return vote;
  }

  async getUserVoteForPoll(pollId: number, userId?: number, voterInfo?: string): Promise<Vote | undefined> {
    if (userId) {
      return this.votes.find(vote => vote.pollId === pollId && vote.userId === userId);
    } else if (voterInfo) {
      return this.votes.find(vote => vote.pollId === pollId && vote.voterInfo === voterInfo);
    }
    return undefined;
  }

  async getVoteStats(): Promise<{ totalVotes: number; activePolls: number; completedPolls: number; participants: number }> {
    const totalVotes = this.votes.length;
    const activePolls = this.polls.filter(poll => poll.status === 'active').length;
    const completedPolls = this.polls.filter(poll => poll.status === 'completed').length;
    const participants = new Set(this.votes.map(vote => vote.userId || vote.voterInfo)).size;

    return {
      totalVotes,
      activePolls,
      completedPolls,
      participants
    };
  }
}

export const storage = new MemStorage();