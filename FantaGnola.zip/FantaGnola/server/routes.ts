import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPollSchema, insertVoteSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import session from "express-session";
import MemoryStore from "memorystore";

const MemStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'fantagnola-secret-key-2024',
    store: new MemStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true if using HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username già in uso" });
      }

      const user = await storage.createUser(userData);
      res.status(201).json({ user: { id: user.id, username: user.username } });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Dati non validi", details: error.errors });
      }
      console.error("Registration error:", error);
      res.status(500).json({ error: "Errore durante la registrazione" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username e password richiesti" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Username o password non corretti" });
      }

      // Store user in session
      (req.session as any).userId = user.id;
      res.json({ user: { id: user.id, username: user.username } });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Errore durante l'accesso" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Errore durante il logout" });
      }
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    try {
      const userId = (req.session as any)?.userId;
      if (!userId) {
        return res.status(401).json({ error: "Non autenticato" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ error: "Utente non trovato" });
      }

      res.json({ user: { id: user.id, username: user.username, role: user.role } });
    } catch (error) {
      console.error("Auth check error:", error);
      res.status(500).json({ error: "Errore del server" });
    }
  });

  // Middleware per autenticazione
  const isAuthenticated = async (req: any, res: any, next: any) => {
    const userId = (req.session as any)?.userId;
    if (!userId) {
      return res.status(401).json({ error: "Non autenticato" });
    }

    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(401).json({ error: "Utente non trovato" });
    }

    req.user = user;
    next();
  };

  // Middleware per verificare se l'utente è admin
  const isAdmin = async (req: any, res: any, next: any) => {
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ error: "Accesso negato: solo gli admin possono eseguire questa azione" });
    }
    next();
  };

  // Get all polls with vote counts
  app.get("/api/polls", async (req, res) => {
    try {
      const polls = await storage.getAllPolls();
      res.json(polls);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch polls" });
    }
  });

  // Get a specific poll with votes
  app.get("/api/polls/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid poll ID" });
      }

      const poll = await storage.getPollWithVotes(id);
      if (!poll) {
        return res.status(404).json({ error: "Poll not found" });
      }

      res.json(poll);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch poll" });
    }
  });

  // Create a new poll (solo admin)
  app.post("/api/polls", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const pollData = insertPollSchema.parse(req.body);
      const poll = await storage.createPoll({
        ...pollData,
        createdBy: req.user.id,
      });
      res.status(201).json(poll);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Dati votazione non validi", details: error.errors });
      }
      res.status(500).json({ error: "Errore nella creazione della votazione" });
    }
  });

  // Update poll status (solo admin)
  app.patch("/api/polls/:id/status", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "ID votazione non valido" });
      }

      const { status } = req.body;
      if (!["draft", "active", "completed"].includes(status)) {
        return res.status(400).json({ error: "Status non valido" });
      }

      const updatedPoll = await storage.updatePoll(id, { status });
      if (!updatedPoll) {
        return res.status(404).json({ error: "Votazione non trovata" });
      }

      res.json(updatedPoll);
    } catch (error) {
      res.status(500).json({ error: "Errore nell'aggiornamento dello status" });
    }
  });

  // Update a poll
  app.patch("/api/polls/:id", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid poll ID" });
      }

      const updates = req.body;
      const updatedPoll = await storage.updatePoll(id, updates);
      
      if (!updatedPoll) {
        return res.status(404).json({ error: "Poll not found" });
      }

      res.json(updatedPoll);
    } catch (error) {
      res.status(500).json({ error: "Failed to update poll" });
    }
  });

  // Delete a poll
  app.delete("/api/polls/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid poll ID" });
      }

      const deleted = await storage.deletePoll(id);
      if (!deleted) {
        return res.status(404).json({ error: "Poll not found" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete poll" });
    }
  });

  // Vote on a poll
  app.post("/api/polls/:id/vote", async (req, res) => {
    try {
      const pollId = parseInt(req.params.id);
      if (isNaN(pollId)) {
        return res.status(400).json({ error: "Invalid poll ID" });
      }

      const voteData = insertVoteSchema.parse({
        ...req.body,
        pollId,
        voterInfo: req.ip // Use IP as voter identifier for anonymous voting
      });

      // Check if poll exists and is active
      const poll = await storage.getPoll(pollId);
      if (!poll) {
        return res.status(404).json({ error: "Poll not found" });
      }

      if (poll.status !== 'active') {
        return res.status(400).json({ error: "Poll is not active" });
      }

      if (poll.expiresAt && new Date() > new Date(poll.expiresAt)) {
        return res.status(400).json({ error: "Poll has expired" });
      }

      // Check if option index is valid
      if (voteData.optionIndex < 0 || voteData.optionIndex >= poll.options.length) {
        return res.status(400).json({ error: "Invalid option index" });
      }

      // Check for duplicate votes if not allowed
      if (!poll.allowMultipleVotes) {
        const existingVote = await storage.getUserVoteForPoll(
          pollId, 
          voteData.userId ? voteData.userId : undefined, 
          voteData.voterInfo ? voteData.voterInfo : undefined
        );
        
        if (existingVote) {
          return res.status(400).json({ error: "You have already voted on this poll" });
        }
      }

      const vote = await storage.createVote(voteData);
      res.status(201).json(vote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid vote data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create vote" });
    }
  });

  // Promuovi utente ad admin (solo admin esistenti)
  app.post("/api/admin/promote/:userId", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const promotedUser = await storage.promoteToAdmin(userId);
      
      if (!promotedUser) {
        return res.status(404).json({ error: "Utente non trovato" });
      }

      res.json({ message: "Utente promosso ad admin", user: promotedUser });
    } catch (error) {
      res.status(500).json({ error: "Errore nella promozione dell'utente" });
    }
  });

  // Ottieni dettagli votazione completata (solo admin)
  app.get("/api/polls/:id/results", isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "ID votazione non valido" });
      }

      const poll = await storage.getPollWithVotes(id);
      if (!poll) {
        return res.status(404).json({ error: "Votazione non trovata" });
      }

      if (poll.status !== 'completed') {
        return res.status(400).json({ error: "La votazione non è ancora completata" });
      }

      // Trova l'opzione vincente
      const maxVotes = Math.max(...Object.values(poll.voteCounts));
      const winningOptions = poll.options.filter((_, index) => poll.voteCounts[index] === maxVotes);

      // Dettagli dei partecipanti
      const participants = await Promise.all(
        poll.votes.map(async (vote) => {
          if (vote.userId) {
            const user = await storage.getUser(vote.userId);
            return {
              type: 'user',
              name: user?.username || 'Utente sconosciuto',
              vote: poll.options[vote.optionIndex],
              votedAt: vote.createdAt
            };
          } else {
            return {
              type: 'anonymous',
              name: 'Anonimo',
              vote: poll.options[vote.optionIndex],
              votedAt: vote.createdAt
            };
          }
        })
      );

      res.json({
        poll,
        winner: winningOptions.length === 1 ? winningOptions[0] : "Pareggio",
        participants,
        totalVotes: poll.voteCount,
        voteCounts: poll.voteCounts
      });
    } catch (error) {
      res.status(500).json({ error: "Errore nel recupero dei risultati" });
    }
  });

  // Get vote statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getVoteStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
